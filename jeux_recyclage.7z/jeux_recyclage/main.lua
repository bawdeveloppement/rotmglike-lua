
local dechets = {
    {
        name ="barquette_aluminium",
        type = "yellow"
    },
    {
        name ="boite_carton",
        type = "yellow"
    },
    {
        name ="boite_concerve",
        type = "yellow"
    },
    {
        name ="bouteille_deau",
        type = "yellow"
    },
    {
        name ="bouteille_lait",
        type = "yellow"
    },
    {
        name ="javel",
        type = "yellow"
    },
    {
        name ="oil_bottle",
        type = "yellow"
    },
    {
        name ="papier_journal",
        type = "yellow"
    },
    {
        name ="apple",
        type = "green"
    },
    {
        name ="banana",
        type = "green"
    },
    {
        name ="carrot",
        type = "green"
    },
    {
        name ="egg",
        type = "green"
    },
    {
        name ="fish_bone",
        type = "green"
    },
    {
        name ="flower",
        type = "green"
    },
    {
        name ="pasteque",
        type = "green"
    },
}

local currentDechets = {}
local player = {
    x = 0,
    y = 0,
    life = 10,
    speed = 100,
    type = "green",
    fireDelay = 1,
    currentFireDelay = 0
}

local bullets = {}


local spawnerDechets = {
    maxTime = 4,
    currentTime = 0.1
}

local totalDechetRecolted = 0

local explosionSound1 = nil
local explosionSound2 = nil
local explosionSound3 = nil

local errorSound = nil

local heartImage = nil

local game = {
    state = "idle"
}

function love.load ()
    heartImage = love.graphics.newImage("textures/heart.png")
    explosionSound1 = love.audio.newSource("sounds/Explosion_001.wav", "static")
    explosionSound2 = love.audio.newSource("sounds/Explosion_002.wav", "static")
    explosionSound3 = love.audio.newSource("sounds/Explosion_003.wav", "static")
    errorSound = love.audio.newSource("sounds/Error_001.wav", "static");
end

function love.update (dt)
    --#region Game Running
    if game.state == "running" then
        if love.keyboard.isDown("q") or love.keyboard.isDown("left") then
            player.x = player.x - player.speed * dt
        end
        if love.keyboard.isDown("d") or love.keyboard.isDown("right") then
            player.x = player.x + player.speed * dt
        end
        if love.keyboard.isDown("z") or love.keyboard.isDown("up") then
            player.y = player.y - player.speed * dt
        end
        if love.keyboard.isDown("s") or love.keyboard.isDown("down") then
            player.y = player.y + player.speed * dt
        end
    
        spawnerDechets.currentTime = spawnerDechets.currentTime - dt
        
        if spawnerDechets.currentTime <= 0 then
            local w, h = love.window.getMode();
            local rX = love.math.random(0, w)
            local rY = love.math.random(0, h)
            local rD = love.math.random(1, #dechets);
            table.insert(currentDechets, #currentDechets + 1, {
                name = dechets[rD].name,
                x = rX,
                y = rY,
                w = 35, h = 107,
                life = 1,
                type = dechets[rD].type,
                image = love.graphics.newImage("textures/".. dechets[rD].type .."/".. dechets[rD].name ..".png")
            });
            spawnerDechets.currentTime = spawnerDechets.maxTime
        end
    
        
        if player.currentFireDelay <= player.fireDelay + 0.1 then
            player.currentFireDelay = player.currentFireDelay - dt
        end
        if love.mouse.isDown(1) and player.currentFireDelay <= 0 then
            local mx, my = love.mouse.getPosition();
            local velx = math.cos(math.atan2(player.y - my, player.x - mx))
            local vely = math.sin(math.atan2(player.y - my, player.x - mx));
    
            table.insert(bullets, #bullets + 1,
            {
                x = player.x,
                y = player.y,
                dx = velx,
                dy = vely,
                type = "green"
            })
            
            player.currentFireDelay = player.fireDelay
        end
    
        for _, value in ipairs(bullets) do
            value.x = value.x - value.dx * 10
            value.y = value.y - value.dy * 10
        end
    
        for iBullet, bullet in ipairs(bullets) do
            for _, dechet in ipairs(currentDechets) do
                local w, h = dechet.image:getDimensions();
                if bullet.x + 16 > dechet.x and bullet.x < dechet.x + w * 0.5 and bullet.y + 16 > dechet.y and bullet.y < dechet.y + h * 0.5 then
                    if player.type == dechet.type then
                        dechet.markDelete = true
                        bullet.markDelete = true
                    else
                        player.life = player.life - 1
                        bullet.markDelete = true
                        errorSound:play()
                    end
                end
            end
    
            if bullet.markDelete == true then
                table.remove(bullets, iBullet);
            end
        end
    
        for index, dechet in ipairs(currentDechets) do
            if dechet.markDelete == true then
                table.remove(currentDechets, index);
                explosionSound1:play()
                totalDechetRecolted = totalDechetRecolted + 1
            end
        end
    
        for index, bullet in ipairs(bullets) do
            
            if bullet.markDelete == true then
                table.remove(bullets, index);
            end
        end
    end
    --#endregion
    
end

function love.keypressed (key)
    if game.state == "running" then
        if key == "f" or key == "kp0" then
            if player.type == "green" then
                player.type = "yellow"
            else
                player.type = "green"
            end
        end
    else
        if key == "space" then
            game.state = "running"
        end
    end
end

function love.draw()
    local ww, wh = love.window.getMode();
    --#region Game Started
    if game.state == "idle" then
        love.graphics.print("Pour commencer appuyez sur la touche Espace", ww / 2 - 300, wh / 2)
    end
    --#endregion

    --#region Game Running
    if game.state == "running" then
        love.graphics.print("Prochain dechet: " .. spawnerDechets.currentTime, ww - 150, 0)
        love.graphics.print("Score: " .. totalDechetRecolted, ww - 150, 20)
    
        if player.type == "green" then
            love.graphics.setColor(0,1,0,1);
        else
            love.graphics.setColor(1,1,0,1);
        end
        love.graphics.rectangle("fill", player.x, player.y, 16, 16);
        love.graphics.setColor(1,1,1,1);
        
        for index, value in ipairs(currentDechets) do
            love.graphics.print(value.name, value.x, value.y - 10);
            love.graphics.draw(value.image, value.x, value.y, 0, 0.5, 0.5)
        end
    
        for index, value in ipairs(bullets) do
            if player.type == "green" then
                love.graphics.setColor(0,1,0,1);
            else
                love.graphics.setColor(1,1,0,1);
            end
            love.graphics.rectangle("fill", value.x, value.y, 16, 16);
            love.graphics.setColor(1,1,1,1);
        end
    
        love.graphics.setColor(0,1,0,1);
        love.graphics.rectangle("fill", ww - 36, wh - 32, 16, 16);
        love.graphics.setColor(1,1,0,1);
        love.graphics.rectangle("fill", ww - 62, wh - 32, 16, 16);
        love.graphics.setColor(1,1,1,1);
        if player.type == "green" then
            love.graphics.rectangle("line", ww - 40, wh - 36, 24, 24);
        else
            love.graphics.rectangle("line", ww - 66, wh - 36, 24, 24);
        end
        
        for i = 1, player.life, 1 do
            local totalSize = 32 * player.life
            love.graphics.draw(heartImage, ww / 2 - totalSize + (4 * player.life) + 36 * (i - 1), wh - 40, 0, 0.5, 0.5)
        end
    end
    --#endregion

    --#region Game Paused
    --#endregion
end