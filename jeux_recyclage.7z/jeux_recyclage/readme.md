Recolte de don pour le maintien de l'association RMZ qui lutte pour la protection de l'environnement
