## Récolte de déchet

Les déchets tombe du ciel et le joueur doit récolter le bon déchet selon la couleur de la poubelle 

# Rogue Like

Si le joueur se fait toucher par un déchet, il perd de la vie
Le joueur a deux types d'armes, un vert et un jaune -> qui fait référence à la poubelle verte et jaune
Si le joueur tire d'un pistolet lazer vert sur un déchet jaune il perd de la vie et l'inverse
Le joueur a 8 caractérisque : 
    - Dextérité -> Réduit l'intervale entre chaque tir
    - Vitalité -> Augmente la regénération par seconde de la vie du joueur
    - Vitesse -> Cours plus vite

# Crafts
    - Poubelle (verte / jaune) = 1000 bouteilles en plastique
    - Fer recyclé = Boite de concerve
    - Composteur = 1000 / 10000 bouteilles en plastique -> Sert à créer du terreau à partir de déchet vert
    - Parcelle de jardin = 4 morceau de bois + 4 terreau + 1 eau
